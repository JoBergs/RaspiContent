#!/usr/bin/python
#encoding: utf-8

def my_function():
    """ This is a docstring for my_function. """

    print 'Executing function my_function'
    return 

if __name__ == '__main__':
    my_function()
