#encoding: utf-8 -*-
from setuptools import setup, find_packages

version = '0.0.0'

setup(
    name='myproject',
    version=version,
    description='A Raspberry Pi python project',
    author=u'Your Name',
    author_email='your@email.com',
    url='https://https://github.com/USERNAME/myproject',
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=[ ]
)
