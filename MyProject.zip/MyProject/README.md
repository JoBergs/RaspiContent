myproject
===========

Enter Readme here!

This function performs ...

def my_function():
    print 'Executing function my_function'
    return



Start the application:
--------

    $ sudo python myproject.py

Update package version::
-------------

Update the version number in setup.py, then

    $ python setup.py sdist
