myproject
===========

Enter Readme here!

This class does something very useful:

    class MyProject(object):
        def covered_method(self):
            print 'Covered by test framework.'
            return 1

Start the application:
--------

    $ sudo python myproject.py

Update package version::
-------------

Update the version number in setup.py, then

    $ python setup.py sdist
