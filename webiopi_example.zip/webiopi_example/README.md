WebIOPi Example
===========

Sample project for the WebIOPi tutorial from Raspython.org, see
http://www.raspython.org/webiopi-a-simple-but-great-web-api-for-the-raspberry-pi/
for further information.

Start the application:
--------

    $ sudo webiopi -d -c /etc/webiopi/config

